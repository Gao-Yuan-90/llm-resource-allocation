from pathlib import Path
import hashlib, json
p = Path(__file__).resolve().parent
m = json.loads((p / "SHA256SUMS.json").read_text(encoding="utf-8"))
for name, expected in m.items():
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == expected, name
print(f"Verified {len(m)} files.")
