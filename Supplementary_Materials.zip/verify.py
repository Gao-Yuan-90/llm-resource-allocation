from pathlib import Path
import importlib.util, os, json, csv
os.environ['MPLCONFIGDIR']=str(Path(__file__).parent/'mplconfig')
import numpy as np
from scipy.optimize import differential_evolution,brentq
root=Path(__file__).resolve().parent
src=root/'reproduce.py'
spec=importlib.util.spec_from_file_location('model',src);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=Path(__file__).parent/'verification';out.mkdir(exist_ok=True)
checks=[]
for kind in m.KINDS:
 for C in (1e19,1e22,1e24):
  r=m.solve(C,kind)
  def fun(x):
   n=np.exp(x[0]);q=x[1];d=C/((6+m.ETA*4096)*n+m.cost(q,kind)-m.cost(m.Q0,kind))
   return m.P['E']+(1+m.P['kappa']*(1-q))*(m.P['A']*n**(-m.P['alpha'])+m.P['B']*d**(-m.P['beta']))
  de=differential_evolution(fun,[(np.log(1e4),np.log(1e16)),(m.Q0,1)],seed=17,tol=1e-11,polish=True)
  checks.append({'kind':kind,'C':C,'branch_loss':r['Loss'],'independent_loss':float(de.fun),'absolute_difference':abs(r['Loss']-de.fun)})
assert max(r['absolute_difference'] for r in checks)<1e-8
# Envelope derivative and profile curvature at interior coordinates, independent finite differences.
derivatives=[]
for kind in m.KINDS:
 q=.8;C=1e19;h=1e-4
 n,d,L,vq=m.inner(q,C,kind);c=6+m.ETA*4096;t=c*n;delta=m.cost(q,kind)-m.cost(m.Q0,kind);s=t+delta
 p=m.P;K=p['B']*C**(-p['beta']);ps=1+p['kappa']*(1-q);gp=m.marginal(q,kind)
 gpp={'exponential':36e7*np.exp(6*q),'power':6e10*q*q,'logarithmic':-2e11/(1+10*q)**2}[kind]
 fuu=ps*(p['alpha']**2*p['A']*n**(-p['alpha'])+p['beta']*K*t*s**(p['beta']-2)*(delta+p['beta']*t))
 fuq=ps*p['beta']*K*t*(p['beta']-1)*s**(p['beta']-2)*gp
 fqq=K*(ps*p['beta']*s**(p['beta']-2)*((p['beta']-1)*gp*gp+s*gpp)-2*p['kappa']*p['beta']*s**(p['beta']-1)*gp)
 exact=fqq-fuq**2/fuu
 lp=m.inner(q+h,C,kind)[2];lm=m.inner(q-h,C,kind)[2]
 derivatives.append({'kind':kind,'first_derivative_error':float(abs((lp-lm)/(2*h)-vq)),'profile_curvature':float(exact),'curvature_error':float(abs((lp-2*L+lm)/h**2-exact))})
assert max(r['curvature_error'] for r in derivatives)<1e-5
# Numerical check of new unique endpoint-crossing theorem for each cost, regardless of interior minima.
endpoint=[]
b=m.P['beta']/(m.P['alpha']+m.P['beta']);r=m.P['alpha']*b;c=6+m.ETA*4096
def profile_H(z):
 def f(y):return m.P['A']*c**m.P['alpha']*np.exp(-m.P['alpha']*y)+m.P['B']*(np.exp(y)+z)**m.P['beta']
 from scipy.optimize import minimize_scalar
 return minimize_scalar(f,bounds=(-60,60),method='bounded',options={'xatol':1e-12}).fun
H0=profile_H(0);zstar=brentq(lambda z:profile_H(z)-(1+m.P['kappa']*(1-m.Q0))*H0,1e-10,1e8)
for kind in m.KINDS:
 delta=float(m.cost(1,kind)-m.cost(m.Q0,kind));cm=(delta/zstar)**(1/b)
 err=float(abs(m.inner(1,cm,kind)[2]-m.inner(m.Q0,cm,kind)[2]))
 endpoint.append({'kind':kind,'endpoint_crossing_budget':cm,'equal_loss_error':err,'is_global_crossing':kind=='logarithmic'})
assert max(x['equal_loss_error'] for x in endpoint)<1e-8
# Deliberate calibration sensitivity: original notebook printed .4755, supplied English code uses .4754.
rounding=[]
for C in (1e19,1e22,1e24):
 a=m.solve(C);p=dict(m.P,kappa=.4755);bcase=m.solve(C,p=p)
 rounding.append({'C':C,'Q_4754':a['Q'],'Q_4755':bcase['Q'],'loss_4754':a['Loss'],'loss_4755':bcase['Loss'],'relative_N_change':bcase['N']/a['N']-1})
summary={'independent_global_checks':checks,'derivative_checks':derivatives,'endpoint_crossing_checks':endpoint,'kappa_rounding_sensitivity':rounding,'runtime':{'numpy':np.__version__}}
(out/'verification.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
