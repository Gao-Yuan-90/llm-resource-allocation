"""Reproducible mathematical case study, not an LLM training experiment.
Run: python reproduce.py --output results
Requires numpy, scipy, matplotlib. No original datasets or posterior chains needed.
All scales use parameter counts, token counts and modelled FLOPs, not billions.
"""
from pathlib import Path
import argparse, json, csv
import numpy as np
from scipy.optimize import brentq, minimize_scalar
import os
os.environ.setdefault('MPLCONFIGDIR', str(Path(__file__).resolve().parent / '.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P = dict(E=1.6899,A=406.4,alpha=.3400,B=410.,beta=.2799,kappa=.4754)
Q0=.5825
ETA=2e-4
KINDS=('exponential','power','logarithmic')

def cost(q,kind):
    q=np.asarray(q)
    if kind=='exponential': return 1e7*np.exp(6*q)
    if kind=='power': return 5e9*q**4
    if kind=='logarithmic': return 2e9*np.log1p(10*q)
    raise ValueError(kind)

def marginal(q,kind):
    if kind=='exponential': return 6e7*np.exp(6*q)
    if kind=='power': return 2e10*np.asarray(q)**3
    if kind=='logarithmic': return 2e10/(1+10*np.asarray(q))
    raise ValueError(kind)

def inner(q,C,kind='exponential',context=4096,psi=1.,p=P,cost_scale=1.):
    if C <= 0 or cost_scale <= 0: raise ValueError('Positive budget and cost scale required')
    q=np.asarray(q,dtype=float); delta=cost_scale*(cost(q,kind)-cost(Q0,kind))
    c=6+ETA*context
    # Stable logarithmic ratio of the two positive terms in the F_u equation.
    def logratio(u):
        logt=np.log(c)+u
        logs=np.logaddexp(logt,np.log(np.maximum(delta,np.finfo(float).tiny)))
        return (np.log(psi*p['beta']*p['B']/(p['alpha']*p['A']))
                -p['beta']*np.log(C)+(p['beta']-1)*logs+logt+p['alpha']*u)
    lo=np.full(q.shape,-40.); hi=np.full(q.shape,100.)
    assert np.all(logratio(lo)<0) and np.all(logratio(hi)>0)
    for _ in range(90):
        mid=(lo+hi)/2; positive=logratio(mid)>0
        hi=np.where(positive,mid,hi); lo=np.where(positive,lo,mid)
    N=np.exp((lo+hi)/2); D=C/(c*N+delta)
    R=p['A']*N**(-p['alpha'])+psi*p['B']*D**(-p['beta'])
    L=p['E']+(1+p['kappa']*(1-q))*R
    dV=-p['kappa']*R+(1+p['kappa']*(1-q))*psi*p['beta']*p['B']*D**(-p['beta'])*cost_scale*marginal(q,kind)/(c*N+delta)
    return N,D,L,dV

def solve(C,kind='exponential',context=4096,psi=1.,p=P,nq=1025,cost_scale=1.):
    qs=np.linspace(Q0,1,nq); vals=inner(qs,C,kind,context,psi,p,cost_scale)[3]
    roots=[]
    for j in np.where(vals[:-1]*vals[1:]<0)[0]:
        roots.append(brentq(lambda q:float(inner(q,C,kind,context,psi,p,cost_scale)[3]),qs[j],qs[j+1],xtol=1e-13))
    cand=np.array([Q0,1]+roots); N,D,L,_=inner(cand,C,kind,context,psi,p,cost_scale)
    j=int(np.argmin(L)); q=float(cand[j]); n=float(N[j]); d=float(D[j])
    out=dict(C=float(C),kind=kind,context=context,psi=psi,N=n,D=d,Q=q,Loss=float(L[j]),ratio=d/n,
             training=6*n*d/C,attention=ETA*context*n*d/C,quality=d*cost_scale*float(cost(q,kind)-cost(Q0,kind))/C)
    return out

def threshold(kind,q):
    return np.exp(brentq(lambda z: float(inner(q,np.exp(z),kind)[3]),np.log(1e5),np.log(1e35),xtol=1e-12))

def equivalent(target,kind,context,quality=True):
    def value(logC):
        C=np.exp(logC)
        return solve(C,kind,context)['Loss'] if quality else float(inner(Q0,C,kind,context)[2])
    return np.exp(brentq(lambda z:value(z)-target,np.log(1e5),np.log(1e40),xtol=1e-12))

def scenarios(seed=2026,S=300):
    """Constructed perturbations for sensitivity analysis, NOT fitted posterior draws.
    Pivot correlation prevents changing exponents while ignoring coefficient units.
    """
    rng=np.random.default_rng(seed)
    alpha=P['alpha']+.03*rng.standard_normal(S)
    beta=P['beta']+.025*rng.standard_normal(S)
    if np.any(alpha <= 0) or np.any(beta <= 0): raise ValueError('Invalid nonpositive exponent draw; specify a positive-support scenario model')
    return dict(E=P['E']+.08*rng.standard_normal(S),alpha=alpha,beta=beta,
                A=np.exp(np.log(P['A'])+(alpha-P['alpha'])*np.log(1e9)+.08*rng.standard_normal(S)),
                B=np.exp(np.log(P['B'])+(beta-P['beta'])*np.log(1e11)+.08*rng.standard_normal(S)),
                kappa=P['kappa']*np.exp(.15*rng.standard_normal(S)))

def scenario_losses(u,q,C,ps,context=4096,kind='exponential'):
    N=np.exp(u); D=C/((6+ETA*context)*N+cost(q,kind)-cost(Q0,kind))
    return ps['E']+(1+ps['kappa']*(1-q))*(ps['A']*N**(-ps['alpha'])+ps['B']*D**(-ps['beta']))

def tail(x,a=.8):
    if not 0 <= a < 1 or len(x) == 0: raise ValueError('CVaR requires nonempty samples and 0 <= a < 1')
    # Exact empirical upper CVaR, including fractional mass if S*(1-a) is not integer.
    v=np.sort(x)[::-1]; m=len(v)*(1-a); k=int(np.floor(m+1e-10)); f=m-k
    return float((v[:k].sum()+(f*v[k] if f>1e-10 else 0))/m)

def risk_solve(C,ps,mode='loss_cvar',oracle=None,nq=129,a=.8):
    def objective(u,q):
        losses=scenario_losses(u,q,C,ps)
        if mode=='mean': return float(np.mean(losses))
        if mode=='regret_cvar': losses=losses-oracle
        return tail(losses,a)
    def profile(q):
        fit=minimize_scalar(lambda u:objective(u,q),bounds=(np.log(1e4),np.log(1e16)),method='bounded',options={'xatol':1e-10})
        return fit.fun,fit.x
    qs=np.linspace(Q0,1,nq); prof=[profile(q) for q in qs]; vs=np.array([r[0] for r in prof])
    candidates=[(vs[0],prof[0][1],qs[0]),(vs[-1],prof[-1][1],qs[-1])]
    for j in np.where((vs[1:-1]<vs[:-2])&(vs[1:-1]<vs[2:]))[0]+1:
        fit=minimize_scalar(lambda q:profile(q)[0],bounds=(qs[j-1],qs[j+1]),method='bounded',options={'xatol':1e-10})
        val,u=profile(fit.x); candidates.append((val,u,fit.x))
    val,u,q=min(candidates)
    losses=scenario_losses(u,q,C,ps); regrets=losses-oracle
    D=C/((6+ETA*4096)*np.exp(u)+cost(q,'exponential')-cost(Q0,'exponential'))
    return dict(C=C,method=mode,N=float(np.exp(u)),D=float(D),Q=float(q),objective=float(val),
                mean_loss=float(losses.mean()),loss_cvar=tail(losses,a),mean_regret=float(regrets.mean()),
                regret_cvar=tail(regrets,a),regret_p95=float(np.quantile(regrets,.95)),
                nominal_penalty=float(scenario_losses(u,q,C,{k:np.array([v]) for k,v in P.items()})[0])-solve(C)['Loss'])

def dumpcsv(path,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        fields=list(dict.fromkeys(k for row in rows for k in row))
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def main(output):
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    rows=[]; transitions=[]
    for kind in KINDS:
        for C in (1e19,1e22,1e24):
            r=solve(C,kind);r['quality_equivalence']=equivalent(r['Loss'],kind,4096,False)/C;rows.append(r)
        t1=threshold(kind,Q0);t2=threshold(kind,1.)
        tm=None
        if kind=='logarithmic':
            tm=float(np.exp(brentq(lambda z:float(inner(1,np.exp(z),kind)[2]-inner(Q0,np.exp(z),kind)[2]),np.log(1e10),np.log(1e25))))
        transitions.append(dict(kind=kind,lower_boundary=t1,upper_boundary=t2,Maxwell=tm))
    dumpcsv(out/'nominal.csv',rows)
    ctx=[]
    for C in (1e19,1e22,1e24):
        for ell in (2048,4096,8192,32768,131072):
            r=solve(C,context=ell);r['M_context']=C/equivalent(r['Loss'],'exponential',2048);ctx.append(r)
    dumpcsv(out/'context.csv',ctx)
    ps=scenarios(); np.savez(out/'constructed_scenarios.npz',**ps)
    risk=[]
    for C in (1e19,1e22,1e24):
        oracle=np.array([solve(C,p={k:float(v[s]) for k,v in ps.items()},nq=257)['Loss'] for s in range(300)])
        nom=solve(C); losses=scenario_losses(np.log(nom['N']),nom['Q'],C,ps); regrets=losses-oracle
        risk.append(dict(C=C,method='nominal',N=nom['N'],D=nom['D'],Q=nom['Q'],objective=nom['Loss'],mean_loss=float(losses.mean()),loss_cvar=tail(losses),mean_regret=float(regrets.mean()),regret_cvar=tail(regrets),regret_p95=float(np.quantile(regrets,.95)),nominal_penalty=0.))
        for mode in ('mean','loss_cvar','regret_cvar'): risk.append(risk_solve(C,ps,mode,oracle))
    dumpcsv(out/'risk_sensitivity.csv',risk)
    # Verify analytical identities, feasibility and numerical resolution where material.
    residuals=[]; equiv=[]; outer=[]
    for kind in KINDS:
        for C in np.logspace(16,26,13):
            r=solve(C,kind)
            lhs=P['alpha']*P['A']*r['N']**(-P['alpha'])*((6+ETA*4096)*r['N']+cost(r['Q'],kind)-cost(Q0,kind))
            rhs=P['beta']*P['B']*r['D']**(-P['beta'])*(6+ETA*4096)*r['N']
            residuals.append(abs(lhs-rhs)/lhs)
            r2=solve(C,kind,nq=4097);outer.append(abs(r['Loss']-r2['Loss']))
            for psi in (1.053,1.089,1.198):
                a=solve(C,kind,psi=psi);b=solve(C/psi**(1/P['beta']),kind)
                equiv.append(abs(a['Loss']-b['Loss']))
    # Increasing Q at fixed C and N creates only an accounting cost, no quality benefit in budget.
    checks=dict(max_inner_relative_residual=max(residuals),max_profile_resolution_loss_change=max(outer),max_mixture_identity_loss_error=max(equiv),max_budget_share_error=max(abs(r['training']+r['attention']+r['quality']-1) for r in rows))
    assert checks['max_inner_relative_residual']<1e-11
    assert checks['max_mixture_identity_loss_error']<1e-9
    assert checks['max_budget_share_error']<1e-12
    meta=dict(parameters=P,Q0=Q0,eta=ETA,transitions=transitions,checks=checks,uncertainty='constructed perturbation scenarios; not posterior samples',seed=2026,S=300)
    (out/'metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    Cs=np.logspace(15,25,181); colors=['#264D73','#AD6C1F','#478263']
    fig,ax=plt.subplots(1,2,figsize=(10.4,3.8))
    for kind,color in zip(KINDS,colors):
        rr=[solve(C,kind,nq=257) for C in Cs]
        ax[0].semilogx(Cs,[r['Q'] for r in rr],label=kind,color=color,lw=2)
        ax[1].loglog(Cs,[r['ratio'] for r in rr],label=kind,color=color,lw=2)
    ax[0].axhline(Q0,color='gray',lw=.7,ls=':');ax[0].set(xlabel='Budget C (modelled FLOPs)',ylabel='Optimal quality Q')
    ax[1].set(xlabel='Budget C (modelled FLOPs)',ylabel='Optimal token to parameter ratio D/N')
    ax[0].legend(frameon=False);fig.tight_layout();fig.savefig(out/'figure1.png',dpi=220);plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(10.4,3.8))
    cm=transitions[-1]['Maxwell']; qs=np.linspace(Q0,1,301)
    for f,color in zip((.7,1.,1.3),colors):
        values=inner(qs,f*cm,'logarithmic')[2]
        ax[0].plot(qs,values-values[0],label=rf'$C/C_M={f:g}$',color=color)
    ax[0].axhline(0,color='gray',lw=.7);ax[0].set(xlabel='Quality Q',ylabel='Profile loss relative to Q0');ax[0].legend(loc='lower left',frameon=True,facecolor='white',edgecolor='none',framealpha=1.)
    for C,color in zip((1e19,1e22,1e24),colors):
        rr=[r for r in ctx if r['C']==C];rr.sort(key=lambda r:r['context'])
        ax[1].semilogx([r['context'] for r in rr],[r['M_context'] for r in rr],marker='o',label=rf'$C=10^{{{int(np.log10(C))}}}$',color=color)
    ls=np.logspace(3.3,5.2,100);ax[1].semilogx(ls,(6+ETA*ls)/(6+ETA*2048),color='gray',ls='--',label='Fixed quality baseline')
    ax[1].set(xlabel='Context length (tokens)',ylabel='Equal loss compute ratio');ax[1].legend(frameon=False,fontsize=8)
    fig.tight_layout();fig.savefig(out/'figure2.png',dpi=220);plt.close(fig)
    print(json.dumps(meta,indent=2));print('Risk sensitivity:',json.dumps(risk,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='results');args=ap.parse_args();main(args.output)
