"""Independent objectives and joint optimizers; archive all constructed ensembles.
Run after run_all.py. This is a mathematical sensitivity study, not LLM training.
"""
from pathlib import Path
import csv,hashlib,json,platform
import numpy as np
import scipy
from scipy.optimize import differential_evolution,linprog
import reproduce as m

OUT=Path(__file__).parent/'independent_checks';OUT.mkdir(exist_ok=True)
C=1e19;Q0=.5825
def losses(x,ps,budget=C):
    # Written directly from equations (1)-(2), without scenario_losses().
    n=np.exp(x[0]);q=x[1]
    d=budget/(6.8192*n+1e7*(np.exp(6*q)-np.exp(6*Q0)))
    return ps['E']+(1+ps['kappa']*(1-q))*(ps['A']/n**ps['alpha']+ps['B']/d**ps['beta'])
def cvar(x,a=.8):
    # Rockafellar-Uryasev threshold representation, independent of tail sorting.
    z=np.quantile(x,a,method='inverted_cdf')
    return float(z+np.maximum(x-z,0).mean()/(1-a))
def lp_cvar(x,a):
    n=len(x)
    # min z + sum(t_i)/(n*(1-a)), z+t_i>=x_i, t_i>=0
    A=np.zeros((n,n+1));A[:,0]=-1;A[np.arange(n),np.arange(n)+1]=-1
    fit=linprog(np.r_[1,np.full(n,1/(n*(1-a)))],A_ub=A,b_ub=-x,bounds=[(None,None)]+[(0,None)]*n,method='highs')
    assert fit.success,fit.message
    return float(fit.fun)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
saved=np.load(Path(__file__).parent/'results/constructed_scenarios.npz')
generated=m.scenarios()
assert all(np.array_equal(saved[k],generated[k]) for k in saved.files)
ensembles=[];oracles={}
for seed,S in [(2026,300),(2027,300),(2028,300),(2026,100),(2026,1000)]:
    ps=m.scenarios(seed,S)
    rr=[m.solve(C,p={k:float(v[s]) for k,v in ps.items()},nq=513) for s in range(S)]
    oracle=np.array([r['Loss'] for r in rr]);oracles[seed,S]=(ps,oracle)
    assert all(1e4<r['N']<1e16 for r in rr)
    path=OUT/f'scenarios_seed{seed}_S{S}.npz'
    np.savez_compressed(path,**ps,oracle_C1e19=oracle)
    ensembles.append(dict(seed=seed,S=S,file=path.name,sha256=sha(path),oracle_grid=513,
                          oracle_min_N=min(r['N'] for r in rr),oracle_max_N=max(r['N'] for r in rr)))
    print('Archived',seed,S,flush=True)
ps,oracle=oracles[2026,300]
csvpath=Path(__file__).parent/'results/risk_sensitivity.csv'
rows=list(csv.DictReader(csvpath.open(encoding='utf8')))
checks=[];tail_errors=[];joint=[]
for row in rows:
    if float(row['C'])!=C:continue
    x=[np.log(float(row['N'])),float(row['Q'])]
    ls=losses(x,ps);reg=ls-oracle
    metrics=dict(mean_loss=float(ls.mean()),loss_cvar=cvar(ls),regret_cvar=cvar(reg),regret_p95=float(np.quantile(reg,.95)))
    errors={k:abs(v-float(row[k])) for k,v in metrics.items()}
    assert max(errors.values())<1e-9,errors
    for a in (.5,.8,.95,.813):
        for arr in (ls,reg):tail_errors.append(abs(cvar(arr,a)-lp_cvar(arr,a)))
    mode=row['method']
    def objective(y):
        v=losses(y,ps)
        return float(v.mean()) if mode=='mean' else cvar(v-oracle if mode=='regret_cvar' else v)
    if mode!='nominal':
        for seed in (72,314):
            fit=differential_evolution(objective,[(np.log(1e4),np.log(1e16)),(Q0,1)],seed=seed,tol=1e-11,atol=1e-12,popsize=25,maxiter=1500,polish=True)
            difference=float(row['objective'])-fit.fun
            assert abs(difference)<1e-7,(mode,difference)
            joint.append(dict(method=mode,seed=seed,N=float(np.exp(fit.x[0])),Q=float(fit.x[1]),objective=float(fit.fun),reported_objective=float(row['objective']),objective_difference=difference))
    checks.append(dict(method=mode,errors=errors,metrics=metrics,min_regret=float(reg.min())))
    assert reg.min()>-1e-8
# Check a deterministic spread of individual oracle problems with another optimizer.
oracle_checks=[]
for s in np.linspace(0,299,12,dtype=int):
    p={k:v[s:s+1] for k,v in ps.items()}
    fit=differential_evolution(lambda x:float(losses(x,p)[0]),[(np.log(1e4),np.log(1e16)),(Q0,1)],seed=89,tol=1e-11,atol=1e-12,popsize=20)
    err=abs(fit.fun-oracle[s]);assert err<1e-8
    oracle_checks.append(dict(scenario=int(s),objective_error=float(err)))
assert max(tail_errors)<1e-9
summary=dict(saved_array_exactly_matches_generator=True,generator='numpy.random.default_rng / PCG64',
             random_draw_order=['alpha','beta','E','A innovation','B innovation','kappa innovation'],
             nonpositive_exponent_policy='raise ValueError; no rejection resampling or clipping',
             ensembles=ensembles,table4=checks,independent_joint_optimizations=joint,
             max_cvar_threshold_vs_LP_error=max(tail_errors),oracle_spot_checks=oracle_checks,
             scope='Constructed-scenario model consistency; no empirical training or posterior validation',
             runtime=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__))
(OUT/'independent_audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
