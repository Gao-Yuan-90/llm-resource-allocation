"""English publication figures, regenerated from the unchanged allocation model."""
from pathlib import Path
import sys,json,csv
import numpy as np
PKG=Path(__file__).resolve().parent
sys.path.insert(0,str(PKG));import reproduce as m
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
OUT=PKG/'english_figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
colors=['#264D73','#AD6C1F','#478263']
def save(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=320,bbox_inches='tight',facecolor='white')
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',facecolor='white');plt.close(fig)
fig,ax=plt.subplots(figsize=(8.2,2.7));ax.set(xlim=(-.15,10.05),ylim=(0,3.3));ax.axis('off')
boxes=[(.05,1.12,2.20,1.12,'Budget $C$\nBaseline quality $Q_0$\nCost and response\nassumptions'),
       (3.05,1.12,2.35,1.12,'Joint allocation\nModel size $N$\nTraining tokens $D$\nQuality $Q$'),
       (6.25,2.0,3.55,.95,'Loss response\nModel-size and data terms'),
       (6.25,.35,3.55,.95,'Resource accounting\nTraining + context + preparation')]
for x,y,w,h,t in boxes:
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.07',facecolor='#F0F4F7',edgecolor='#304D65',lw=1.1))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=10.3)
for xy,xytext in [((2.97,1.68),(2.35,1.68)),((6.16,2.45),(5.5,1.88)),((6.16,.82),(5.5,1.43))]:ax.annotate('',xy=xy,xytext=xytext,arrowprops=dict(arrowstyle='->',lw=1.25,color='#304D65'))
fig.tight_layout(pad=.3);save(fig,'figure1')

fig,ax=plt.subplots(1,2,figsize=(8.2,3.5));curve=[]
for kind,label,color in zip(m.KINDS,['Exponential','Power','Logarithmic'],colors):
    Cs=np.logspace(15,25,181);rr=[m.solve(C,kind,nq=257) for C in Cs];curve.extend(rr)
    ax[0].semilogx(Cs,[r['Q'] for r in rr],label=label,color=color,lw=1.8)
    ax[1].loglog(Cs,[r['ratio'] for r in rr],color=color,lw=1.8)
ax[0].axhline(m.Q0,color='gray',ls=':',lw=.7)
ax[0].set(xlabel='Budget $C$ (modeled FLOPs)',ylabel='Optimal quality $Q$')
ax[1].set(xlabel='Budget $C$ (modeled FLOPs)',ylabel='Optimal token-to-parameter ratio $D/N$')
ax[0].legend(frameon=False,fontsize=8)
for i,a in enumerate(ax):a.text(.01,1.04,'(a)' if i==0 else '(b)',transform=a.transAxes)
fig.tight_layout(pad=.7,w_pad=1.2);save(fig,'figure2');m.dumpcsv(OUT/'figure2_data.csv',curve)

fig,ax=plt.subplots(1,2,figsize=(8.2,3.5));curve=[]
for rho,color in zip((.1,1.,10.),colors):
    Cs=np.logspace(16,24,101);rr=[m.solve(C,cost_scale=rho,nq=513) for C in Cs]
    curve.extend(dict(rho=rho,**r) for r in rr)
    ax[0].semilogx(Cs,[r['Q'] for r in rr],color=color,label=rf'$\rho={rho:g}$',lw=1.8)
    ax[1].semilogx(Cs/rho**((m.P['alpha']+m.P['beta'])/m.P['beta']),[r['Q'] for r in rr],color=color,label=rf'$\rho={rho:g}$',lw=1.8)
ax[0].set(xlabel='Budget $C$ (modeled FLOPs)',ylabel='Optimal quality $Q$')
ax[1].set(xlabel=r'Transformed budget $C/\rho^{1/b}$',ylabel='Optimal quality $Q$')
for i,a in enumerate(ax):a.legend(frameon=False,fontsize=9);a.text(.01,1.04,'(a)' if i==0 else '(b)',transform=a.transAxes)
fig.tight_layout(pad=.7,w_pad=1.2);save(fig,'figure3');m.dumpcsv(OUT/'figure3_data.csv',curve)

meta=json.loads((PKG/'results/metadata.json').read_text(encoding='utf8'));cm=meta['transitions'][-1]['Maxwell']
fig,ax=plt.subplots(1,2,figsize=(8.2,3.9));profile=[];qs=np.linspace(m.Q0,1,301)
for factor,color in zip((.7,1.,1.3),colors):
    val=m.inner(qs,factor*cm,'logarithmic')[2]
    ax[0].plot(qs,val-val[0],color=color,label=rf'$C/C_M={factor:g}$',lw=1.7)
    profile.extend(dict(factor=factor,Q=float(q),loss_difference=float(v-val[0])) for q,v in zip(qs,val))
ax[0].axhline(0,color='gray',lw=.7)
ax[0].set(xlabel='Quality $Q$',ylabel=r'Profile loss $V(Q;C)-V(Q_0;C)$')
ax[0].legend(loc='lower center',bbox_to_anchor=(.5,1.02),ncol=3,frameon=False,fontsize=7.8,handlelength=1.3,columnspacing=.8)
ctx=list(csv.DictReader((PKG/'results/context.csv').open(encoding='utf8')))
for C,color in zip((1e19,1e22,1e24),colors):
    rr=sorted([r for r in ctx if float(r['C'])==C],key=lambda r:int(r['context']))
    ax[1].semilogx([int(r['context']) for r in rr],[float(r['M_context']) for r in rr],marker='o',markersize=4,color=color,label=rf'$C=10^{{{int(np.log10(C))}}}$')
ls=np.logspace(3.3,5.2,100)
ax[1].semilogx(ls,(6+m.ETA*ls)/(6+m.ETA*2048),color='gray',ls='--',label='Fixed baseline quality')
ax[1].set(xlabel='Context length (tokens)',ylabel='Equal-loss budget ratio')
ax[1].legend(frameon=False,fontsize=8,loc='upper left')
for i,a in enumerate(ax):a.text(.01,1.15 if i==0 else 1.04,'(a)' if i==0 else '(b)',transform=a.transAxes)
fig.subplots_adjust(left=.09,right=.99,bottom=.16,top=.82,wspace=.34);save(fig,'figureB1')
m.dumpcsv(OUT/'figureB1_profiles.csv',profile)
print('Four English figures and their numerical data generated.',flush=True)
