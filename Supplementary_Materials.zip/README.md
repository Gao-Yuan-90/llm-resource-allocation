# Supplementary materials

## Manuscript

Joint resource allocation for language model training with data preparation costs

This package contains an independent implementation of the mathematical and numerical case study. It does not contain newly trained language model weights or empirical posterior samples. The response coefficients and preparation cost functions are fixed scenario inputs. The reference coefficients were adopted from the supplied competition modeling materials; the complete original competition datasets are not redistributed here and are not needed to reproduce these case studies.

## Quick start

Use a clean Python environment. The verified environment was Python 3.14.7, NumPy 2.5.3, SciPy 1.18.1, and Matplotlib 3.11.2. From the package root:

```text
python -m pip install -r requirements.txt
python reproduce.py --output results
python verify.py
python baseline_comparison.py
python risk_robustness.py
python extended_study.py
python independent_audit.py
python make_english_figures.py
```

These commands regenerate outputs inside this directory. Preserve a copy of the supplied outputs if exact file comparisons are needed. No GPUs, model weights, or original notebook helper modules are required. Cross-platform optimization and image-rendering differences may occur.

## Files and manuscript mapping

| Manuscript item | Inputs, script, or output |
| --- | --- |
| Table 1 | fixed_inputs.json; P, Q0, ETA, and cost() in reproduce.py |
| Table 2 | baseline_comparison.py; restructured_results/table2_allocations.csv |
| Table 3 | extended_study.py; extended_results/response_sensitivity.csv |
| Table 4 | reproduce.py; results/risk_sensitivity.csv |
| Table C1 | risk_robustness.py; verification/risk_robustness.csv and .json |
| Table C2 | extended_study.py; extended_results/offset_stress.csv |
| Figure 1 | make_english_figures.py; english_figures/figure1.png and .pdf (schematic) |
| Figure 2 | english_figures/figure2_data.csv; generated PNG and PDF |
| Figure 3 | english_figures/figure3_data.csv; generated PNG and PDF |
| Figure B1 | english_figures/figureB1_profiles.csv; results/context.csv; generated PNG and PDF |
| Cost transformation | extended_results/cost_scale_identity.csv; extended_results/verification.json |
| Numerical verification | verification/verification.json; independent_checks/independent_audit.json |

## Constructed scenarios

The generator is NumPy default_rng / PCG64. It draws S normal values for alpha, beta, E, additional A noise, additional B noise, and kappa, in that order. Nonpositive exponents cause an error; no rejection resampling or clipping is applied. Perturbation amplitudes are specified sensitivity inputs, not estimated uncertainty intervals.

Five archives in independent_checks cover (seed, S) = (2026, 300), (2027, 300), (2028, 300), (2026, 100), and (2026, 1000). They include scenario coefficients and scenario-optimal losses at C = 1e19. Samples at different sizes are generated separately rather than as nested prefixes. results/constructed_scenarios.npz contains the base ensemble. Empirical CVaR uses fractional boundary mass when required.

The independent audit checks a separately implemented objective, the CVaR threshold representation against linear programming, two differential-evolution seeds for the risk objectives, and 12 scenario-optimal allocations. These checks assess numerical consistency for the stated cases; they do not establish global guarantees for arbitrary nonconvex problems or validate the response against real training runs.

## Verification and integrity

verification_history.json records the checks reused for this submission package. The scientific scripts and outputs were retained from the independently verified package. Submission preparation changes packaging and documentation only. SHA256SUMS.json lists all other distributed files. Verify it with:

```text
python check_integrity.py
```

## Data categories

The source competition materials are pre-existing background inputs. The scenario arrays are constructed numerical data. Optimized allocations, risk metrics, and plotted curves are numerical results generated for the case study. Absence of new language model training does not imply absence of newly generated numerical data. This package supplies the inputs and outputs needed for the reported case-study calculations, without claiming to reproduce all four original competition tasks or validate every upstream data record.
