"""Cost-scale, response-placement and offset stress checks for the manuscript.
Run after reproduce.py; no original competition data or helper modules required.
"""
from pathlib import Path
import json, csv, platform
import numpy as np
import scipy
from scipy.optimize import brentq, minimize_scalar, differential_evolution
import reproduce as m
import matplotlib.pyplot as plt

OUT=Path(__file__).parent/'extended_results'; OUT.mkdir(exist_ok=True)
def dump(name,rows): m.dumpcsv(OUT/name,rows)

# Independently solved cost-scaled problems: verify every allocation component.
checks=[]; sensitivity=[]
for kind in m.KINDS:
    for kap in (.2,m.P['kappa'],.8):
        p=dict(m.P,kappa=kap); b=p['beta']/(p['alpha']+p['beta'])
        for rho in (.1,1.,10.):
            for C in (1e17,1e19,1e22):
                a=m.solve(C,kind,p=p,cost_scale=rho)
                z=m.solve(C/rho**(1/b),kind,p=p)
                checks.append(dict(kind=kind,kappa=kap,rho=rho,C=C,
                    Q_error=abs(a['Q']-z['Q']),
                    N_relative_error=abs(a['N']/(rho*z['N'])-1),
                    D_relative_error=abs(a['D']/(rho**(p['alpha']/p['beta'])*z['D'])-1),
                    loss_error=abs(a['Loss']-p['E']-rho**(-p['alpha'])*(z['Loss']-p['E']))))
                sensitivity.append(dict(kappa=kap,rho=rho,**a))
dump('cost_scale_identity.csv',checks); dump('cost_scale_sensitivity.csv',sensitivity)
assert max(x['loss_error'] for x in checks)<1e-10
assert max(x['N_relative_error'] for x in checks)<1e-8
print('Cost-scale checks',len(checks),flush=True)

# General response placement: common, data-only, parameter-only quality response.
# Stable inner derivative ratio uses the quality coefficient on each term.
def alternative_inner(q,C,kind,rho,placement,p=m.P):
    q=np.asarray(q,float); ps=1+p['kappa']*(1-q)
    pa=ps if placement in ('common','parameter_only') else np.ones_like(q)
    pb=ps if placement in ('common','data_only') else np.ones_like(q)
    delta=rho*(m.cost(q,kind)-m.cost(m.Q0,kind)); c=6+m.ETA*4096
    def ratio(u):
        lt=np.log(c)+u; ls=np.logaddexp(lt,np.log(np.maximum(delta,np.finfo(float).tiny)))
        return np.log(pb/pa)+np.log(p['beta']*p['B']/(p['alpha']*p['A']))-p['beta']*np.log(C)+(p['beta']-1)*ls+lt+p['alpha']*u
    lo=np.full(q.shape,-40.);hi=np.full(q.shape,100.)
    assert np.all(ratio(lo)<0) and np.all(ratio(hi)>0)
    for _ in range(90):
        mid=(lo+hi)/2; sg=ratio(mid)>0;hi=np.where(sg,mid,hi);lo=np.where(sg,lo,mid)
    N=np.exp((lo+hi)/2);D=C/(c*N+delta)
    LA=p['A']*N**(-p['alpha']);LB=p['B']*D**(-p['beta'])
    benefit=-p['kappa']*((LA if placement in ('common','parameter_only') else 0)+(LB if placement in ('common','data_only') else 0))
    derivative=benefit+pb*p['beta']*LB*rho*m.marginal(q,kind)/(c*N+delta)
    return N,D,p['E']+pa*LA+pb*LB,derivative
def alternative_solve(C,kind,rho,placement,nq=1025):
    qs=np.linspace(m.Q0,1,nq);v=alternative_inner(qs,C,kind,rho,placement)[3]; roots=[]
    for j in np.where(v[:-1]*v[1:]<0)[0]:
        roots.append(brentq(lambda q:float(alternative_inner(q,C,kind,rho,placement)[3]),qs[j],qs[j+1],xtol=1e-12))
    cand=np.array([m.Q0,1]+roots);N,D,L,_=alternative_inner(cand,C,kind,rho,placement);i=np.argmin(L)
    return dict(C=C,kind=kind,rho=rho,placement=placement,N=float(N[i]),D=float(D[i]),Q=float(cand[i]),Loss=float(L[i]))
responses=[];response_checks=[]
for placement in ('common','data_only','parameter_only'):
    for kind in m.KINDS:
        for rho in (.1,1.,10.):
            for C in (1e19,1e22,1e24):
                a=alternative_solve(C,kind,rho,placement);z=alternative_solve(C,kind,rho,placement,4097)
                responses.append(a);response_checks.append(dict(placement=placement,kind=kind,rho=rho,C=C,grid_loss_error=abs(a['Loss']-z['Loss'])))
                if placement=='common': assert abs(a['Loss']-m.solve(C,kind,cost_scale=rho)['Loss'])<1e-10
dump('response_sensitivity.csv',responses)
assert max(x['grid_loss_error'] for x in response_checks)<1e-9
# Nine independent joint optimizations for the added response models.
joint=[]
for placement in ('common','data_only','parameter_only'):
    for kind in m.KINDS:
        def obj(x):
            u,q=x;N=np.exp(u);D=1e19/((6+m.ETA*4096)*N+m.cost(q,kind)-m.cost(m.Q0,kind)); ps=1+m.P['kappa']*(1-q)
            return m.P['E']+(ps if placement!='data_only' else 1)*m.P['A']*N**(-m.P['alpha'])+(ps if placement!='parameter_only' else 1)*m.P['B']*D**(-m.P['beta'])
        r=differential_evolution(obj,[(np.log(1e4),np.log(1e16)),(m.Q0,1)],seed=37,tol=1e-11)
        joint.append(dict(placement=placement,kind=kind,loss_error=abs(r.fun-alternative_solve(1e19,kind,1,placement)['Loss'])))
assert max(x['loss_error'] for x in joint)<1e-8
print('Response models',len(responses),flush=True)

# Matched scenario perturbations: only irreducible offsets change.
C=1e19;ps=m.scenarios();oracle=np.array([m.solve(C,p={k:float(v[s]) for k,v in ps.items()},nq=513)['Loss'] for s in range(300)])
nom=m.solve(C);offset_rows=[];invariance=[]
base_reg=m.risk_solve(C,ps,'regret_cvar',oracle,nq=257)
for scale in (0.,1.,3.):
    altered={k:v.copy() for k,v in ps.items()}; altered['E']=m.P['E']+scale*(ps['E']-m.P['E']); shift=altered['E']-ps['E']; new_oracle=oracle+shift
    ls=m.scenario_losses(np.log(nom['N']),nom['Q'],C,altered);reg=ls-new_oracle
    for mode in ('nominal','loss_cvar','regret_cvar'):
        if mode=='nominal': r=dict(method=mode,N=nom['N'],D=nom['D'],Q=nom['Q'],loss_cvar=m.tail(ls),regret_cvar=m.tail(reg))
        else: r=m.risk_solve(C,altered,mode,new_oracle,nq=257)
        offset_rows.append(dict(offset_sd=.08*scale,**r))
        if mode=='regret_cvar': invariance.append(dict(offset_sd=.08*scale,objective_error=abs(r['regret_cvar']-base_reg['regret_cvar']),Q_error=abs(r['Q']-base_reg['Q']),N_relative_error=abs(r['N']/base_reg['N']-1)))
assert max(x['objective_error'] for x in invariance)<1e-9
dump('offset_stress.csv',offset_rows)
summary=dict(cost_scale_cases=len(checks),max_cost_scale_loss_error=max(x['loss_error'] for x in checks),
    max_cost_scale_Q_error=max(x['Q_error'] for x in checks),max_cost_scale_N_relative_error=max(x['N_relative_error'] for x in checks),
    response_cases=len(responses),max_response_grid_error=max(x['grid_loss_error'] for x in response_checks),
    independent_response_checks=joint,offset_invariance=invariance,
    runtime=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__))
(OUT/'verification.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans'})
fig,axes=plt.subplots(1,2,figsize=(10.4,3.8))
for rho,col in zip((.1,1.,10.),('#264D73','#AD6C1F','#478263')):
    Cs=np.logspace(16,24,101);rr=[m.solve(c,cost_scale=rho,nq=513) for c in Cs]
    axes[0].semilogx(Cs,[r['Q'] for r in rr],color=col,label=rf'$\rho={rho:g}$')
    axes[1].semilogx(Cs/rho**((m.P['alpha']+m.P['beta'])/m.P['beta']),[r['Q'] for r in rr],color=col,label=rf'$\rho={rho:g}$')
axes[0].set(xlabel='Budget C (modelled FLOPs)',ylabel='Optimal quality Q')
axes[1].set(xlabel=r'Rescaled budget $C/\rho^{1/b}$',ylabel='Optimal quality Q')
for ax in axes:ax.legend(frameon=False);ax.spines[['top','right']].set_visible(False)
fig.tight_layout();fig.savefig(OUT/'figure3.png',dpi=240);plt.close(fig)
print(json.dumps(summary,indent=2),flush=True)
