"""Run from the supplementary directory to regenerate the added strategy comparison."""
from pathlib import Path
import csv,json
import reproduce as m

out=Path(__file__).parent/'restructured_results';out.mkdir(exist_ok=True)
rows=[]
for C in (1e19,1e22,1e24):
    N,D,L,_=m.inner(m.Q0,C)
    rows.append(dict(C=C,strategy='Baseline',N=float(N),D=float(D),Q=m.Q0,Loss=float(L),ratio=float(D/N),quality_equivalence=1.))
    for kind in m.KINDS:
        r=m.solve(C,kind)
        r['quality_equivalence']=m.equivalent(r['Loss'],kind,4096,False)/C
        rows.append({k:r[k] for k in ('C','N','D','Q','Loss','ratio','quality_equivalence')}|{'strategy':kind})
for row in rows:
    assert abs(row['D']*((6+m.ETA*4096)*row['N']+(0 if row['strategy']=='Baseline' else m.cost(row['Q'],row['strategy'])-m.cost(m.Q0,row['strategy'])))/row['C']-1)<1e-12
with (out/'table2_allocations.csv').open('w',newline='',encoding='utf8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/'baseline_allocations.json').write_text(json.dumps([r for r in rows if r['strategy']=='Baseline'],indent=2),encoding='utf8')
print('Verified 12 strategy allocations, including 3 fixed-quality baselines.')
