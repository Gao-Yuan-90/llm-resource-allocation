from pathlib import Path
import importlib.util,json,csv
import numpy as np
pkg=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('allocation',pkg/'reproduce.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
C=1e19;cache={};rows=[]
configs=[(2026,300,.5),(2026,300,.8),(2026,300,.95),(2027,300,.8),(2028,300,.8),(2026,100,.8),(2026,1000,.8)]
for seed,S,a in configs:
 key=(seed,S)
 if key not in cache:
  ps=m.scenarios(seed,S)
  oracle=np.array([m.solve(C,p={k:float(v[s]) for k,v in ps.items()},nq=513)['Loss'] for s in range(S)])
  cache[key]=(ps,oracle)
 ps,oracle=cache[key]
 nom=m.solve(C);ls=m.scenario_losses(np.log(nom['N']),nom['Q'],C,ps);reg=ls-oracle
 baseline={'C':C,'method':'nominal','N':nom['N'],'D':nom['D'],'Q':nom['Q'],'objective':nom['Loss'],'mean_loss':float(ls.mean()),'loss_cvar':m.tail(ls,a),'mean_regret':float(reg.mean()),'regret_cvar':m.tail(reg,a),'regret_p95':float(np.quantile(reg,.95)),'nominal_penalty':0.}
 for mode in ['nominal','loss_cvar','regret_cvar']:
  x=baseline if mode=='nominal' else m.risk_solve(C,ps,mode,oracle,nq=257,a=a)
  rows.append(dict(seed=seed,S=S,confidence=a,**x))
 print(seed,S,a,flush=True)
with (pkg/'verification/risk_robustness.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=[]
for seed,S,a in configs:
 rr=[x for x in rows if x['seed']==seed and x['S']==S and x['confidence']==a];n,l,r=rr
 summary.append({'seed':seed,'S':S,'confidence':a,'loss_cvar_change':l['loss_cvar']-n['loss_cvar'],'regret_cvar_change_under_loss_optimization':l['regret_cvar']-n['regret_cvar'],'regret_cvar_change_under_regret_optimization':r['regret_cvar']-n['regret_cvar']})
(pkg/'verification/risk_robustness.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
